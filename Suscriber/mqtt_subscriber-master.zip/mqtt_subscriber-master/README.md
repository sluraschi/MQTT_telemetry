# MQTT Cloud Suscriber

Short script that suscribes to a topic from a Heroku MQTT Broker.

## Authors

* Belgrano, Mateo
* Luraschi, Sebastian F.

## Acknowledgments

* [Official guide to deploy app](https://devcenter.heroku.com/articles/getting-started-with-python#introduction)
* [Official guide about worker](https://devcenter.heroku.com/articles/background-jobs-queueing)
* [Guided "Simple twitter-bot with Python, Tweepy and Heroku"](http://briancaffey.github.io/2016/04/05/twitter-bot-tutorial.html)
