from enum import Enum


class Topics(Enum):
    SEISMIC = "/pi/test"
    T_AND_H = "/pi/temp"
    ULTRASOUND = "/pi/ultrasound"
    EXAMPLE = "/example"
