BASE_ENDPOINT = "https://telemetria-temperatura.herokuapp.com/"
HOST = "tailor.cloudmqtt.com"
USER = "sfluras-dev"
PW = "sebas32"
