
class Payload:
    def to_dict(self):
        raise NotImplementedError

    def to_tuple(self):
        raise NotImplementedError
